
<section class="header-mainbar">
	
	<div class="top-row">
		<div class="col">
			<img id="head-icon" width="400" height="80" src="./images/brand-logo.png" alt="">
		</div>
		<div class="col">
			<div class="col-in-row">
				<div class="col-social">
				<a target="_blank" href="https://www.facebook.com/www.futurecomputer.net/"><i class="fa fa-facebook"></i></a>
				<a target="_blank" href="https://www.youtube.com/channel/UC5ggk_Ki-YcTkv9TeQkaPDQ?sub_confirmation=1"><i class="fa fa-youtube"></i></a>
				<a target="_blank" href="https://www.instagram.com/zahidhasan3845/"><i class="fa fa-instagram"></i></a>
				<a target="_blank" href="https://www.linkedin.com/in/md-zahid-hossain-24284b240/"><i class="fa fa-linkedin"></i></a>
				<a target="_blank" href="https://twitter.com/ZahidHa28052337"><i class="fa fa-twitter"></i></a>
				</div>
				<div class="col-login">
						<a href="" target="blank">Admin</a>
				</div>
			</div>
		</div>
	</div>
	</section>