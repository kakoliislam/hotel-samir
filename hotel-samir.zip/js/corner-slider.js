
	var i = 0; // Start point
	var images = [];
	var time = 3000;

	// Image List
	images[0] = 'images/slider1.jpg';
	images[1] = 'images/slider2.jpg';
	images[2] = 'images/slider3.jpg';


	// Change Image
	function changeImg(){
		document.slide.src = images[i];

		if(i < images.length - 1){
			i++;
		} else {
			i = 0;
		}

		setTimeout("changeImg()", time);
	}

	window.onload = changeImg;



