<div style="text-align:center;">
    <img style="width:100%;" src="images/404.png" alt="alt"/>
</div>